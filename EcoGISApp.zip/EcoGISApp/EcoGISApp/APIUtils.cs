﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using Newtonsoft.Json;
using System.Text;
using System.Threading.Tasks;
using EcoGISApp.DTO.AQ;
using EcoGISApp.DTO.OWM.AP;
using EcoGISApp.DTO.OWM.UVI;

namespace EcoGISApp
{
    public static class APIUtils
    {

        private static string OWMUri = "http://api.openweathermap.org/";
        private static string AQIUri = "https://api.waqi.info/feed/";

        private static string OWMKey = "ab1523e9d42e1cfe95c62ed50b86b731";
        private static string AQIKey = "0580e9b5c82abdd542d5f5047e7e2f53a64d23d9";

        private static string UVIAdd = "data/2.5/";

        private static string AP = "pollution/v1/o3/";
        private static string UVI = $"/uvi?appid={OWMKey}&";

        public static async Task<int> GetAQResult(string lat, string lon)
        {

            using (var client = new HttpClient())
            {

                string url = AQIUri + $"geo:{lat};{lon}/?token={AQIKey}";
            
                var response = await client.GetStringAsync(url);

                var obj = JsonConvert.DeserializeObject<AQResponse>(response);

                return obj.data.aqi;

            }

        }

        public static async Task<float> GetAPResult(string lat, string lon)
        {

            using (var client = new HttpClient())
            {

                string url = OWMUri + AP + $"{lat},{lon}/2016Z.json?appid={OWMKey}";
            
                try
                {
                    var response = await client.GetStringAsync(url);
                    var obj = JsonConvert.DeserializeObject<APResponse>(response);
                    return obj.data;

                } catch(Exception e)
                {
                    return -1;
                }

            }

        }

        public static async Task<float> GetUVIResult(string lat, string lon)
        {

            using (var client = new HttpClient())
            {

                string url = OWMUri + UVIAdd + UVI + $"lat={lat}&lon={lon}";

                var response = await client.GetStringAsync(url);

                var obj = JsonConvert.DeserializeObject<UVIResponse>(response);

                return obj.value;

            }

        }

    }
}
