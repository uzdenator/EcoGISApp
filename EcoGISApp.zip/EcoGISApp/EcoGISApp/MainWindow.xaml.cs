﻿using Microsoft.Maps.MapControl.WPF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EcoGISApp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Map_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;

            Point pos = e.GetPosition(this);

            Location pinLocation = mainMap.ViewportPointToLocation(pos);

            string lat = pinLocation.Latitude.ToString().Replace(',', '.');
            string lon = pinLocation.Longitude.ToString().Replace(',', '.');

            Pushpin pin = new Pushpin();
            pin.Location = pinLocation;

            if (mainMap.Children.Count != 0)
            {
                mainMap.Children.RemoveAt(mainMap.Children.Count - 1);
            }

            mainMap.Children.Add(pin);

            var uvi = await APIUtils.GetUVIResult(lat, lon);
            var o3 = await APIUtils.GetAPResult(lat, lon);
            var aqi = await APIUtils.GetAQResult(lat, lon);

            uvIndex.Text = uvi.ToString();
            O3Level.Text = o3 != -1 ? o3.ToString() : "No info";
            aqIndex.Text = aqi.ToString();

            SetGrades(uvi, o3, aqi);

        }

        private void SetGrades(float uvi, float o3, int aqi)
        {

            if (0 < uvi && uvi < 2.9)
            {
                uvIndex.Foreground = Brushes.Green;
            }
            else if (3 < uvi && uvi < 5.9)
            {
                uvIndex.Foreground = Brushes.Yellow;
            }
            else if (6 < uvi && uvi < 7.9)
            {
                uvIndex.Foreground = Brushes.Orange;
            }
            else if (8 < uvi && uvi < 10.9)
            {
                uvIndex.Foreground = Brushes.Red;
            }

            if (Enumerable.Range(0, 50).Contains(aqi))
            {
                aqIndex.Foreground = Brushes.Green;
            } else if (Enumerable.Range(51, 100).Contains(aqi))
            {
                aqIndex.Foreground = Brushes.Yellow;
            } else if (Enumerable.Range(101, 150).Contains(aqi))
            {
                aqIndex.Foreground = Brushes.Orange;
            } else if (Enumerable.Range(151, 300).Contains(aqi))
            {
                aqIndex.Foreground = Brushes.Red;
            }

        }



    }
}
