﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EcoGISApp.DTO.OWM.UVI
{
    class UVIResponse
    {
        public float value { get; set; }
    }
}
