﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EcoGISApp.DTO.OWM.AP
{
    class APResponse
    {
        public float data { get; set; }
    }
}
