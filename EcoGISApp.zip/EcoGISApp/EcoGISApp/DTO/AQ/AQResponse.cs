﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EcoGISApp.DTO.AQ
{
    class AQResponse
    {

        public string status { get; set; }

        public AQData data { get; set; }
    }
}
